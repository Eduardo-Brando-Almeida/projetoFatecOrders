export interface IOrder {
  date: string;
  cpf: string;
  payment_method: string;
  itens_qtd: number;
  total_value: number;
}
